# GrandNexus v7.3.0

**An anchored translator and a reference engine that decide without inventing, and a laboratory to measure whether a loop learns.**

Claude translates a text and a question into a small logic language (anchored to the text: every statement quotes
the span it comes from); the reference engine `nexus_logic` decides (yes / no / unknown / contradictory) with a printable
proof, checked against clingo; the answer is the strict verdict (text only), the background-knowledge verdict is reported apart.
Measured on FOLIO v2 validation (203 items, 6 runs): 83.1% with 7 asserted errors per run, Claude alone 84.5% with 22-25; on 100 fresh
train items: 78/100 with 2 asserted errors, Claude alone 79/100 with 11. The learning loop (verified corrections kept as experience,
`grandnexus/cognition/experience.py`) was measured by `tools/bench_learning.py` in two pre-registered tests and is **not demonstrated**:
neither transfer to new texts nor recall of a corrected reading of the same text beats the controls (logbook 62).
Everything else in this repository (the 2025 cognitive-architecture scaffolding: memories, graph, orchestrator, 15/05 layer)
is an experimental ground around that core, kept and runnable but not demonstrated.

This archive is a complete, self-contained snapshot: no notebook chain, no `%%writefile`, no update to graft.

## Quick start (Colab or any Python 3.10+)
```bash
unzip GrandNexus_v7.3.0.zip -d /content              # -> /content/GrandNexus
pip install -q -r /content/GrandNexus/requirements.txt
```
```python
import sys; sys.path.insert(0, "/content/GrandNexus")
from grandnexus.boot import boot
gn = boot(llm="auto")          # nx pathway (Claude -> nexus_logic) if ANTHROPIC_API_KEY is set, else grammar only
# gn = boot(profile="minimal") # only the demonstrated core, NexusCore as orchestrator (17 modules, 0.05 s; MODULES.md)
gn.print_report()
tr = gn.modules()["text_reasoner"]
print(tr.answer("All men are mortal. Socrates is a man. Is Socrates mortal?")["answer"])
gn.shutdown()
```
Modes: laboratory (default, deterministic, nothing runs in the background) or live (`boot(start_core=True)` / `gn.start()`).

## What is where
| Path | Content |
|---|---|
| `grandnexus/` | the package (core, memories, cognition, graph, LLM interface, 15/05 layer) |
| `grandnexus/boot.py`, `grandnexus/module_status.py`, `MODULES.md` | assembles the system (profile full: everything; profile minimal: the core only); the status of every module (core / supported / experimental / archive) |
| `grandnexus/nexus_logic/` | the core: language spec, parser, reference engine (disjunctions, formulas, reductio), clingo export, bridge |
| `grandnexus/llm_interface/translator_v5.py` | Claude as anchored translator into the nexus_logic language (prompt v5.4), Claude-alone control |
| `grandnexus/cognition/reasoning/text_reasoner.py` | text -> program/premises -> reference engine -> verdict (grammar, JSON and nx pathways) |
| `grandnexus/cognition/experience.py` | the learning loop: verified corrections as experience, TF-IDF retrieval, shown as examples to the reader |
| `grandnexus/cognition/deliberation.py` | the deliberation experiment (several readings, targeted re-reading; hypothesis rejected, logbook 44) |
| `grandnexus/llm_interface/llm_translator.py` | the earlier JSON translator (prompt versions v1-v4), kept for comparison |
| `tools/bench_folio.py`, `tools/bench_deliberation.py`, `tools/diff_engines.py` | FOLIO bench (content-sha freezing, trivial controls, --strict), deliberation bench, differential reference / clingo / home engine |
| `tools/bench_learning.py`, `tools/story_split.py` | learning-loop bench (none / static / random / learned, story-aware draws, read items excluded, paired sign tests, power and cost printed, checkpoint/resume) and the offline story split of archived runs |
| `tools/cost.py`, `tools/colab_save.py` | API cost of a run from the recorded usage (prompt cache included); safe Colab save (zips the repository it belongs to, checks the results are inside) |
| `tools/test_bench.py` | bench for hand-written sets: freezes a set, measures 4 modes, never prints item texts |
| `tools/smoke_test.py`, `tools/lab_*.py` | import test, labs (controls, layer oracles) |
| `tests_lab/test_*.py` | offline tests (no API) |
| `STATUS.md`, `LOGBOOK.md` | one-page current state; logbook: every hypothesis -> result -> decision (66 entries) |
| `tests_lab/resultats/` | every FOLIO and learning run: results JSON, saved memories, the translated programs |
| `archive/` | original 15/05 and 29/05 sources (untouched) |
| `.git` | full history: every repair is one commit (`git log --oneline`) |

## Checks
```bash
cd /content/GrandNexus
python tools/smoke_test.py
for t in tests_lab/test_*.py; do python $t; done
python tools/diff_engines.py tests_lab/programmes_nx      # reference engine vs clingo (pip install clingo)
python tools/bench_folio.py --split train --seed 2 --n 100 --modes translator,direct --strict   # needs ANTHROPIC_API_KEY
```

## Language
Code, tools, tests, logbook and README are in English. The legacy 2025 modules (outside the core) still carry French
comments and log messages; they will be translated in a later pass.
