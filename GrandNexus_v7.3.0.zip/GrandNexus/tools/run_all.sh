#!/usr/bin/env bash
# Applique les réparations une par une, un commit chacune.
set -e
cd "$(dirname "$0")"
declare -A MSG=(
 [r2_syntax]="R2 syntaxe: attention_filter (méthode à 3 espaces) + reasoning_core (bloc sur-indenté L1686-1829)"
 [r3_dataclasses]="R3 dataclasses Task/TaskRequest: kw_only=True (champ obligatoire après défaut)"
 [r4_graph_factory]="R4 graph_engine V2: create_graph_engine remise au niveau module + alias GraphEngine"
 [r5_aliases]="R5 alias: PlanningEngine, ReinforcementLearner, AdaptationManager, Reflector, ConfidenceEstimator, MetaMonitor"
 [r6_missing_classes]="R6 LearningResult créée + create_pattern_mining sortie de la classe"
 [r7_event_bus]="R7 NexusCore: bus publication/abonnement (register_handler, publish_event, schedule_task)"
 [r8_cognitive_contract]="R8 contrat inter-modules: contracts.py + routage de capacités + constructeurs alignés"
 [r10_flat_namespace_imports]="R10 imports manquants hérités de l'espace de noms plat du notebook (pyflakes)"
 [r11_logic_bugs]="R11 bugs logiques: boucle de clustering (remaining coupé) + arrêt ErrorRecovery en code mort"
 [r12_graph_registry]="R12 GraphModuleManager: ModuleRegistry utilisé comme instance partagée du core"
 [r13_shared_graph]="R13 GraphModuleManager accepte le graphe partagé (graph_engine_instance)"
 [r14_reason_workspace_contract]="R14 ReasoningCore: contexte et prémisses rangés là où les stratégies les cherchent"
 [r24_message_queue_tiebreak]="R24 NexusCore: file de messages départagée (priorités égales -> TypeError, threads émetteurs tués)"
 [r25_manager_bridges]="R25 CognitionManager: 12 méthodes appelées mais absentes -> ponts de délégation"
 [r31_interruptible_loops]="R31 boucles de fond interruptibles (CognitiveMonitor, ErrorRecovery) : arrêt de 17 s"
 [r32_deduction_fixpoint]="R32 déduction: chaînage jusqu'à stabilité (avant: 2 pas) + contraposée"
 [r33_llm_engine_anthropic]="R33 LLMEngine Anthropic: modèle configuré et consigne système transmis (ancien défaut retiré)"
 [r34_anthropic_sampling_and_receipts]="R34 LLMEngine: no default temperature (rejected by recent Claude models), one retry without it, API receipts"
 [r35_graph_manager_interface]="R35 GraphModuleManager: start/stop/handle_message expected by ModuleRegistry"
 [r36_registry_status_order]="R36 ModuleRegistry: status pushed to NexusCore only once the core knows the module"
 [r38_conjunctive_rules]="R38 deduction: rules with several conditions (fixpoint with one-condition propagation)"
 [r39_numbered_list_regex]="R39 ReasoningCore: numbered-list detection used a literal string instead of a regex"
 [r9_robustness]="R9 robustesse: create_anomaly_filter hors classe, annotation ast différée, replis sans PyTorch"
)
for r in r2_syntax r3_dataclasses r4_graph_factory r5_aliases r6_missing_classes r7_event_bus r8_cognitive_contract r9_robustness r10_flat_namespace_imports r11_logic_bugs r12_graph_registry r13_shared_graph r14_reason_workspace_contract r24_message_queue_tiebreak r25_manager_bridges r31_interruptible_loops r32_deduction_fixpoint r33_llm_engine_anthropic r34_anthropic_sampling_and_receipts r35_graph_manager_interface r36_registry_status_order r38_conjunctive_rules r39_numbered_list_regex; do
  python3 repairs.py "$r"
  (cd .. && git add -A && git commit -qm "${MSG[$r]}")
done
